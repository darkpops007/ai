from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import SeleniumScrapingTool

@CrewBase
class EquipeCrewAiPourAnalyseDuMarcheCryptoEnTempsReelCrew():
    """EquipeCrewAiPourAnalyseDuMarcheCryptoEnTempsReel crew"""

    @agent
    def Market Data Scraper(self) -> Agent:
        return Agent(
            config=self.agents_config['Market Data Scraper'],
            tools=[SeleniumScrapingTool()],
        )

    @agent
    def Technical Analyst(self) -> Agent:
        return Agent(
            config=self.agents_config['Technical Analyst'],
            tools=[],
        )

    @agent
    def Market Sentiment Analyst(self) -> Agent:
        return Agent(
            config=self.agents_config['Market Sentiment Analyst'],
            tools=[],
        )

    @agent
    def Dashboard Manager(self) -> Agent:
        return Agent(
            config=self.agents_config['Dashboard Manager'],
            tools=[],
        )

    @agent
    def Alert System(self) -> Agent:
        return Agent(
            config=self.agents_config['Alert System'],
            tools=[],
        )


    @task
    def scrape_market_news_task(self) -> Task:
        return Task(
            config=self.tasks_config['scrape_market_news_task'],
            tools=[SeleniumScrapingTool()],
        )

    @task
    def analyze_technical_indicators_task(self) -> Task:
        return Task(
            config=self.tasks_config['analyze_technical_indicators_task'],
            tools=[],
        )

    @task
    def analyze_market_sentiment_task(self) -> Task:
        return Task(
            config=self.tasks_config['analyze_market_sentiment_task'],
            tools=[],
        )

    @task
    def build_real_time_dashboard_task(self) -> Task:
        return Task(
            config=self.tasks_config['build_real_time_dashboard_task'],
            tools=[],
        )

    @task
    def trigger_alerts_task(self) -> Task:
        return Task(
            config=self.tasks_config['trigger_alerts_task'],
            tools=[],
        )


    @crew
    def crew(self) -> Crew:
        """Creates the EquipeCrewAiPourAnalyseDuMarcheCryptoEnTempsReel crew"""
        return Crew(
            agents=self.agents, # Automatically created by the @agent decorator
            tasks=self.tasks, # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )
